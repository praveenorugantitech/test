package com.praveen.restclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PraveenRestclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
