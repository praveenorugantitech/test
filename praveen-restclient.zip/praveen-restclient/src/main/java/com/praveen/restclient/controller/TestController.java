package com.praveen.restclient.controller;

import com.praveen.restclient.service.AuthService;
import com.praveen.restclient.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class TestController {

    private final AuthService authService;
    private final UserService userService;

    @PostMapping("/token")
    public String fetchToken() {
        return authService.fetchToken();
    }

    @GetMapping("/user-info")
    public String getUserInfo(){
        return  userService.getUserInfo();
    }
}
