package com.praveen.restclient.service;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

@RequiredArgsConstructor
@Service
public class AuthService {

    private final RestClient restClient;

    public String fetchToken(){

        try {
            return restClient.post().uri("https://dummyjson.com/auth/login")
                    .body(new Credentials("emilys", "emilyspass"))
                    .retrieve().toEntity(TokenResponse.class).getBody().getAccessToken();
        } catch (RestClientException e) {
            throw new RuntimeException("Error fetching token", e);
        }
    }

    // Inner class for the credentials
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    public static class Credentials {
        private String username;
        private String password;
    }

    // Inner class for the token response
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    public static class TokenResponse {
        private String accessToken;
    }
}


