package com.praveen.restclient.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

@RequiredArgsConstructor
@Service
public class UserService {
    private final RestClient restClient;
    private final AuthService authService;

    public String getUserInfo() {
        String accessToken = authService.fetchToken();
        return restClient
                .get()
                .uri("https://dummyjson.com/auth/me")
                .header("Authorization", "Bearer " + accessToken)
                .retrieve()
                .toEntity(String.class).getBody();
    }

}
