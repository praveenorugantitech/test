package com.praveen.restclient;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestClient;

@SpringBootApplication
public class RestclientApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestclientApplication.class, args);
    }


    @Bean
    OpenAPI customOpenAPI(Environment env) {

        return new OpenAPI().components(new Components())
                .info(new Info().title("Rest Client Test")
                        .description("Rest Client Test"));
    }

    @Bean
    public RestClient restClient() {
        return RestClient.create();
    }
}
