package com.praveen.currency.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import java.time.LocalDate;

@Entity
public class CurrencyExchange {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String currencyCode;
    private Double exchangeRateToInr;
    private Boolean isValid;
    private Integer version;
    private LocalDate createdDate;
    private String createdBy;
    private LocalDate modifiedDate;

    public CurrencyExchange() {

    }

    public CurrencyExchange(Long id, String currencyCode, Double exchangeRateToInr, boolean isValid, Integer version, LocalDate createdDate, String createdBy, LocalDate modifiedDate, String modifiedBy) {
        this.id = id;
        this.currencyCode = currencyCode;
        this.exchangeRateToInr = exchangeRateToInr;
        this.isValid = isValid;
        this.version = version;
        this.createdDate = createdDate;
        this.createdBy = createdBy;
        this.modifiedDate = modifiedDate;
        this.modifiedBy = modifiedBy;
    }

    private String modifiedBy;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public Double getExchangeRateToInr() {
        return exchangeRateToInr;
    }

    public void setExchangeRateToInr(Double exchangeRateToInr) {
        this.exchangeRateToInr = exchangeRateToInr;
    }

    public boolean isValid() {
        return isValid;
    }

    public void setValid(boolean valid) {
        isValid = valid;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public LocalDate getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDate createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDate getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(LocalDate modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }
}
