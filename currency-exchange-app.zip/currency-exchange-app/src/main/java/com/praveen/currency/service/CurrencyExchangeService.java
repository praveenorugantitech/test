package com.praveen.currency.service;

import com.praveen.currency.dto.CurrencyExchangeDTO;
import com.praveen.currency.dto.CurrencyHistoryExchangeDTO;

import java.util.List;

public interface CurrencyExchangeService {

    List<CurrencyExchangeDTO> fetchCurrencyExchanges();

    List<CurrencyHistoryExchangeDTO> fetchHistoryCurrencyExchangesByCurrencyCode(String currencyCode);

    void updateCurrencyExchanges(List<CurrencyExchangeDTO> currencyExchanges);


}
