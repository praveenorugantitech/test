package com.praveen.currency.dto;

public record CurrencyExchangeDTO(String currencyCode, Double exchangeRateToInr) {
}
