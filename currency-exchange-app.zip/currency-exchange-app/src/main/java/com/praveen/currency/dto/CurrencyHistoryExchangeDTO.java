package com.praveen.currency.dto;

import java.time.LocalDate;

public record CurrencyHistoryExchangeDTO(String currencyCode, Double exchangeRateToInr, Integer version,
                                         String createdBy, LocalDate createdDate, String modifiedBy,
                                         LocalDate modifiedDate) {
}
