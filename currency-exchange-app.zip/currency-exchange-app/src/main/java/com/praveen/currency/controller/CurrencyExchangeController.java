package com.praveen.currency.controller;

import com.praveen.currency.dto.CurrencyExchangeDTO;
import com.praveen.currency.dto.CurrencyHistoryExchangeDTO;
import com.praveen.currency.model.CurrencyExchangeForm;
import com.praveen.currency.service.CurrencyExchangeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/currency-exchange")
public class CurrencyExchangeController {

    private final CurrencyExchangeService currencyExchangeService;

    @Autowired
    public CurrencyExchangeController(CurrencyExchangeService currencyExchangeService) {
        this.currencyExchangeService = currencyExchangeService;
    }

    @GetMapping
    public String showCurrencyExchangeForm(Model model) {
        List<CurrencyExchangeDTO> exchanges = currencyExchangeService.fetchCurrencyExchanges();
        model.addAttribute("currencyExchangeForm", new CurrencyExchangeForm(exchanges));
        return "currency-exchange";
    }

    @PostMapping("/update")
    public String updateExchangeRates(@ModelAttribute("currencyExchangeForm") CurrencyExchangeForm form, RedirectAttributes redirectAttributes) {
        currencyExchangeService.updateCurrencyExchanges(form.exchanges());
        redirectAttributes.addFlashAttribute("success", true);
        return "redirect:/currency-exchange";
    }


    @GetMapping("/history")
    public String viewCurrencyHistory(@RequestParam String currencyCode, Model model) {
        List<CurrencyHistoryExchangeDTO> history = currencyExchangeService.fetchHistoryCurrencyExchangesByCurrencyCode(currencyCode);
        model.addAttribute("currencyCode", currencyCode);
        model.addAttribute("history", history);
        return "currency-exchange-history";
    }
}
