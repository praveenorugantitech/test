package com.praveen.currency.service.impl;

import com.praveen.currency.dto.CurrencyExchangeDTO;
import com.praveen.currency.dto.CurrencyHistoryExchangeDTO;
import com.praveen.currency.entity.CurrencyExchange;
import com.praveen.currency.repository.CurrencyExchangeRepository;
import com.praveen.currency.service.CurrencyExchangeService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class CurrencyExchangeServiceImpl implements CurrencyExchangeService {

    private final CurrencyExchangeRepository currencyExchangeRepository;

    public CurrencyExchangeServiceImpl(CurrencyExchangeRepository currencyExchangeRepository) {
        this.currencyExchangeRepository = currencyExchangeRepository;
    }

    /**
     * Fetch all valid currency exchanges.
     */
    @Override
    public List<CurrencyExchangeDTO> fetchCurrencyExchanges() {
        return currencyExchangeRepository.findByIsValidTrueOrderByCurrencyCodeAsc()
                .stream()
                .map(exchange -> new CurrencyExchangeDTO(exchange.getCurrencyCode(), exchange.getExchangeRateToInr()))
                .toList();
    }

    /**
     * Fetch the historical exchange rate for a given currency code.
     */
    @Override
    public List<CurrencyHistoryExchangeDTO> fetchHistoryCurrencyExchangesByCurrencyCode(String currencyCode) {
        return currencyExchangeRepository.findByCurrencyCodeAndIsValidFalseOrderByVersionDesc(currencyCode)
                .stream()
                .map(exchange -> new CurrencyHistoryExchangeDTO(exchange.getCurrencyCode(), exchange.getExchangeRateToInr(), exchange.getVersion(), exchange.getCreatedBy(), exchange.getCreatedDate(), exchange.getModifiedBy(), exchange.getModifiedDate()))
                .toList();
    }

    /**
     * Update exchange rates using the DTO list.
     */
    @Override
    public void updateCurrencyExchanges(List<CurrencyExchangeDTO> currencyExchanges) {
        for (CurrencyExchangeDTO dto : currencyExchanges) {
            CurrencyExchange currentCurrencyExchange = currencyExchangeRepository
                    .findByCurrencyCodeAndIsValidTrue(dto.currencyCode())
                    .orElseThrow(() -> new IllegalArgumentException("Currency Code " + dto.currencyCode() + " not found"));

            if (!currentCurrencyExchange.getExchangeRateToInr().equals(dto.exchangeRateToInr())) {
                currentCurrencyExchange.setValid(false);
                currencyExchangeRepository.save(currentCurrencyExchange);

                Integer latestVersion = currencyExchangeRepository
                        .findTopVersionByCurrencyCodeAndIsValidFalseOrderByVersionDesc(dto.currencyCode());
                int newVersion = (latestVersion != null ? latestVersion : 0) + 1;

                CurrencyExchange newCurrencyExchange = new CurrencyExchange();
                newCurrencyExchange.setCurrencyCode(dto.currencyCode());
                newCurrencyExchange.setExchangeRateToInr(dto.exchangeRateToInr());
                newCurrencyExchange.setVersion(newVersion);
                newCurrencyExchange.setValid(true);
                newCurrencyExchange.setModifiedBy("Praveen");
                newCurrencyExchange.setCreatedBy("Praveen");
                newCurrencyExchange.setCreatedDate(LocalDate.now());
                newCurrencyExchange.setModifiedDate(LocalDate.now());


                currencyExchangeRepository.save(newCurrencyExchange);
            }

        }
    }
}
