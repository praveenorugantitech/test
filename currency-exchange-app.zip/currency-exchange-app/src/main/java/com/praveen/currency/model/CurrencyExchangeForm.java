package com.praveen.currency.model;

import com.praveen.currency.dto.CurrencyExchangeDTO;

import java.util.List;

public record CurrencyExchangeForm(List<CurrencyExchangeDTO> exchanges) {

}
