package com.praveen.currency.repository;

import com.praveen.currency.entity.CurrencyExchange;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CurrencyExchangeRepository extends JpaRepository<CurrencyExchange, Long> {

    Optional<CurrencyExchange> findByCurrencyCodeAndIsValidTrue(String currencyCode);

    List<CurrencyExchange> findByIsValidTrueOrderByCurrencyCodeAsc();

    List<CurrencyExchange> findByCurrencyCodeAndIsValidFalseOrderByVersionDesc(String currencyCode);

    @Query("SELECT MAX(c.version) FROM CurrencyExchange c WHERE c.currencyCode = :currencyCode AND c.isValid = false")
    Integer findTopVersionByCurrencyCodeAndIsValidFalseOrderByVersionDesc(String currencyCode);
}
