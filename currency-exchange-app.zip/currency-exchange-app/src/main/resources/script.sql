CREATE TABLE CURRENCY_EXCHANGE (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    currency_code VARCHAR(10) NOT NULL,
    exchange_rate_to_inr DOUBLE,
    is_valid BOOLEAN NOT NULL,
    version VARCHAR(50),
    created_date DATE,
    created_by VARCHAR(100),
    modified_date DATE,
    modified_by VARCHAR(100)
);

INSERT INTO CURRENCY_EXCHANGE 
(currency_code, exchange_rate_to_inr, is_valid, version, created_date, created_by, modified_date, modified_by) 
VALUES
('USD', 83.25, true, 1, '2024-12-24', 'admin', '2024-12-24', 'admin'),
('GBP', 102.50, true, 1, '2024-12-24', 'admin', '2024-12-24', 'admin'),
('EUR', 90.10, true, 1, '2024-12-24', 'admin', '2024-12-24', 'admin'),
('JPY', 0.64, true, 1, '2024-12-24', 'admin', '2024-12-24', 'admin');
