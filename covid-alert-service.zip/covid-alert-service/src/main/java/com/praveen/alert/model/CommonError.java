package com.praveen.alert.model;

public record CommonError(String code, String description) {
}
