package com.praveen.alert.model;

import java.util.Map;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(name = "ErrorMessage", example = "Error Details to describe the Client, Business and System Errors")
public record ErrorMessage(@Schema(name = "code", description = "4000,6000,5000", example = "4000") String code,
		@Schema(name = "description", description = "Input Request Validation Failure and Internal Service Failures", example = "Input Request Validation Failure") String description,
		@Schema(name = "errors", example = "{\"400001\":\"Request Json is malformed or invalid\"}") Map<String, String> errors) {
}
