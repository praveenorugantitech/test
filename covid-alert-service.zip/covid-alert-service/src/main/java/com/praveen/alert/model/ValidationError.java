package com.praveen.alert.model;

public record ValidationError(String code, String description) {
}
