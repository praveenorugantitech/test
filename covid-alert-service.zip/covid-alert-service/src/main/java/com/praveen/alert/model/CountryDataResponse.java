package com.praveen.alert.model;

public record CountryDataResponse(String status, CountryData data, ErrorMessage errors) {
}
