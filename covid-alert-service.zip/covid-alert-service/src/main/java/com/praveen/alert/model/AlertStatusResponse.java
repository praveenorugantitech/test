package com.praveen.alert.model;

public record AlertStatusResponse(String status, AlertStatus data, ErrorMessage errors) {
}
