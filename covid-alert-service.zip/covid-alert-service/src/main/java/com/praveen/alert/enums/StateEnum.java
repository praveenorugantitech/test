package com.praveen.alert.enums;
public enum StateEnum {
    ANDAMAN_AND_NICOBAR_ISLANDS("AN", "Andaman and Nicobar Islands"),
    ANDHRA_PRADESH("AP", "Andhra Pradesh"),
    ARUNACHAL_PRADESH("AR", "Arunachal Pradesh"),
    ASSAM("AS", "Assam"),
    BIHAR("BR", "Bihar"),
    CHANDIGARH("CH", "Chandigarh"),
    CHHATTISGARH("CT", "Chhattisgarh"),
    DADRA_AND_NAGAR_HAVELI_AND_DAMAN_AND_DIU("DN", "Dadra and Nagar Haveli and Daman and Diu"),
    DELHI("DL", "Delhi"),
    GOA("GA", "Goa"),
    GUJARAT("GJ", "Gujarat"),
    HARYANA("HR", "Haryana"),
    HIMACHAL_PRADESH("HP", "Himachal Pradesh"),
    JAMMU_AND_KASHMIR("JK", "Jammu and Kashmir"),
    JHARKHAND("JH", "Jharkhand"),
    KARNATAKA("KA", "Karnataka"),
    KERALA("KL", "Kerala"),
    LADAKH("LA", "Ladakh"),
    LAKSHADWEEP("LD", "Lakshadweep"),
    MADHYA_PRADESH("MP", "Madhya Pradesh"),
    MAHARASHTRA("MH", "Maharashtra"),
    MANIPUR("MN", "Manipur"),
    MEGHALAYA("ML", "Meghalaya"),
    MIZORAM("MZ", "Mizoram"),
    NAGALAND("NL", "Nagaland"),
    ODISHA("OD", "Odisha"),
    PUDUCHERRY("PY", "Puducherry"),
    PUNJAB("PB", "Punjab"),
    RAJASTHAN("RJ", "Rajasthan"),
    SIKKIM("SK", "Sikkim"),
    TAMIL_NADU("TN", "Tamil Nadu"),
    TELANGANA("TG", "Telangana"),
    TRIPURA("TR", "Tripura"),
    UTTARAKHAND("UK", "Uttarakhand"),
    UTTAR_PRADESH("UP", "Uttar Pradesh"),
    WEST_BENGAL("WB", "West Bengal");

    private final String code;
    private final String name;

    StateEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    // Method to get state name by state code
    public static String getStateNameByCode(String stateCode) {
        for (StateEnum stateEnum : values()) {
            if (stateEnum.getCode().equalsIgnoreCase(stateCode)) {
                return stateEnum.getName();
            }
        }
        return null; // Return null if not found
    }

    // Optional: Method to check if the state code is valid
    public static boolean isValidStateCode(String stateCode) {
        for (StateEnum stateEnum : values()) {
            if (stateEnum.getCode().equalsIgnoreCase(stateCode)) {
                return true;
            }
        }
        return false;
    }
}
