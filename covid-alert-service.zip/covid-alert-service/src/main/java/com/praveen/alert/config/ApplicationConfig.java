package com.praveen.alert.config;

import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import com.praveen.alert.model.CommonError;
import com.praveen.alert.model.ValidationError;

@Configuration
@ConfigurationProperties(prefix = "app")
public class ApplicationConfig {

	private String openApiTitle;
	private String openApiDescription;

	private String covidStatsLookupApiHost;
	private String covidStatsLookupApiEndpoint;
	private int readTimeout;
	private int connectionTimeout;
	private int retryAttempts;
	private long backOffTimeInMillisec;
	private Map<String, List<ValidationError>> validationErrors;
	private Map<String, CommonError> externalServiceErrors;
	private Map<String, CommonError> businessErrors;
	private CommonError clientError;
	private CommonError messageNotReadableError;
	private CommonError businessError;
	private CommonError invalidHttpMethodError;
	private CommonError invalidInputError;
	private CommonError externalServiceError;
	private CommonError serverError;
	private CommonError serverErrors;
	private String errorMessageNotes;

	public String getOpenApiTitle() {
		return openApiTitle;
	}

	public void setOpenApiTitle(String openApiTitle) {
		this.openApiTitle = openApiTitle;
	}

	public String getOpenApiDescription() {
		return openApiDescription;
	}

	public void setOpenApiDescription(String openApiDescription) {
		this.openApiDescription = openApiDescription;
	}

	public String getCovidStatsLookupApiHost() {
		return covidStatsLookupApiHost;
	}

	public void setCovidStatsLookupApiHost(String covidStatsLookupApiHost) {
		this.covidStatsLookupApiHost = covidStatsLookupApiHost;
	}

	public String getCovidStatsLookupApiEndpoint() {
		return covidStatsLookupApiEndpoint;
	}

	public void setCovidStatsLookupApiEndpoint(String covidStatsLookupApiEndpoint) {
		this.covidStatsLookupApiEndpoint = covidStatsLookupApiEndpoint;
	}

	public int getReadTimeout() {
		return readTimeout;
	}

	public void setReadTimeout(int readTimeout) {
		this.readTimeout = readTimeout;
	}

	public int getConnectionTimeout() {
		return connectionTimeout;
	}

	public void setConnectionTimeout(int connectionTimeout) {
		this.connectionTimeout = connectionTimeout;
	}

	public int getRetryAttempts() {
		return retryAttempts;
	}

	public void setRetryAttempts(int retryAttempts) {
		this.retryAttempts = retryAttempts;
	}

	public long getBackOffTimeInMillisec() {
		return backOffTimeInMillisec;
	}

	public void setBackOffTimeInMillisec(long backOffTimeInMillisec) {
		this.backOffTimeInMillisec = backOffTimeInMillisec;
	}

	public Map<String, List<ValidationError>> getValidationErrors() {
		return validationErrors;
	}

	public void setValidationErrors(Map<String, List<ValidationError>> validationErrors) {
		this.validationErrors = validationErrors;
	}

	public Map<String, CommonError> getExternalServiceErrors() {
		return externalServiceErrors;
	}

	public void setExternalServiceErrors(Map<String, CommonError> externalServiceErrors) {
		this.externalServiceErrors = externalServiceErrors;
	}

	public Map<String, CommonError> getBusinessErrors() {
		return businessErrors;
	}

	public void setBusinessErrors(Map<String, CommonError> businessErrors) {
		this.businessErrors = businessErrors;
	}

	public CommonError getClientError() {
		return clientError;
	}

	public void setClientError(CommonError clientError) {
		this.clientError = clientError;
	}

	public CommonError getMessageNotReadableError() {
		return messageNotReadableError;
	}

	public void setMessageNotReadableError(CommonError messageNotReadableError) {
		this.messageNotReadableError = messageNotReadableError;
	}

	public CommonError getBusinessError() {
		return businessError;
	}

	public void setBusinessError(CommonError businessError) {
		this.businessError = businessError;
	}

	public CommonError getInvalidHttpMethodError() {
		return invalidHttpMethodError;
	}

	public void setInvalidHttpMethodError(CommonError invalidHttpMethodError) {
		this.invalidHttpMethodError = invalidHttpMethodError;
	}

	public CommonError getInvalidInputError() {
		return invalidInputError;
	}

	public void setInvalidInputError(CommonError invalidInputError) {
		this.invalidInputError = invalidInputError;
	}

	public CommonError getExternalServiceError() {
		return externalServiceError;
	}

	public void setExternalServiceError(CommonError externalServiceError) {
		this.externalServiceError = externalServiceError;
	}

	public CommonError getServerError() {
		return serverError;
	}

	public void setServerError(CommonError serverError) {
		this.serverError = serverError;
	}

	public CommonError getServerErrors() {
		return serverErrors;
	}

	public void setServerErrors(CommonError serverErrors) {
		this.serverErrors = serverErrors;
	}

	public String getErrorMessageNotes() {
		return errorMessageNotes;
	}

	public void setErrorMessageNotes(String errorMessageNotes) {
		this.errorMessageNotes = errorMessageNotes;
	}

}
