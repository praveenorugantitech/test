package com.praveen.alert.exception;

public class ExternalServiceException extends RuntimeException {

	private static final long serialVersionUID = 5230287076956915950L;

	// Constructor with a message
	public ExternalServiceException(String message) {
		super(message);
	}

	// Constructor with a message and a cause (for exception chaining)
	public ExternalServiceException(String message, Throwable cause) {
		super(message, cause);
	}

}
