package com.praveen.alert.model;

import java.time.ZonedDateTime;

public record SummaryData(BaseDataClass baseData, int total, int confirmedButLocationUnidentified,
		ZonedDateTime updateTime) {
	public SummaryData withUpdateTime(ZonedDateTime newUpdateTime) {
		return new SummaryData(baseData, total, confirmedButLocationUnidentified, newUpdateTime);
	}
}