package com.praveen.alert.externalservice;

import java.net.UnknownHostException;
import java.time.Duration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StopWatch;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.praveen.alert.config.ApplicationConfig;
import com.praveen.alert.exception.ExternalServiceException;
import com.praveen.alert.model.CovidApiData;

import io.netty.channel.ConnectTimeoutException;
import reactor.util.retry.Retry;

@Service
public class CovidStatsLookupService {

	private static final Logger log = LoggerFactory.getLogger(CovidStatsLookupService.class);

	private final ApplicationConfig appConfig;
	private final WebClient covidStatsLookup;
	private final RestTemplate restTemplate;

	public CovidStatsLookupService(ApplicationConfig appConfig, WebClient covidStatsLookup, RestTemplate restTemplate) {
		this.appConfig = appConfig;
		this.covidStatsLookup = covidStatsLookup;
		this.restTemplate = restTemplate;
	}

	public CovidApiData fetchStatsUsingWebClient() {

		log.info("Covid Stats Lookup Service Request for Host {} and Path {}", appConfig.getCovidStatsLookupApiHost(),
				appConfig.getCovidStatsLookupApiEndpoint());

		CovidApiData covidApiData = null;
		try {
			StopWatch stopWatch = new StopWatch("Covid Stats Lookup Service Call");
			stopWatch.start();
			covidApiData = covidStatsLookup.get().retrieve().bodyToMono(CovidApiData.class).retryWhen(
					Retry.backoff(appConfig.getRetryAttempts(), Duration.ofMillis(appConfig.getBackOffTimeInMillisec()))
							.filter(throwable -> isConnectionTimeout(throwable)))
					.block();
			stopWatch.stop();

			log.info("Covid Stats Lookup Service Execution Times for Host {} and Path {} and Total Time Taken {}",
					appConfig.getCovidStatsLookupApiHost(), appConfig.getCovidStatsLookupApiEndpoint(),
					stopWatch.getTotalTimeMillis());
		} catch (WebClientResponseException webClientResponseException) {
			throw new ExternalServiceException("covidStatsLookupException-" + webClientResponseException.getMessage());

		} catch (Exception exception) {
			throw new ExternalServiceException("covidStatsLookupException-" + exception.getMessage(), exception);

		}
		return covidApiData;
	}

	public CovidApiData fetchStatsUsingRestTemplate() {

		log.info("Covid Stats Lookup Service Request for Host {} and Path {}", appConfig.getCovidStatsLookupApiHost(),
				appConfig.getCovidStatsLookupApiEndpoint());

		CovidApiData covidApiData = null;
		try {
			StopWatch stopWatch = new StopWatch("Covid Stats Lookup Service Call");
			stopWatch.start();
			covidApiData = restTemplate.getForObject(
					appConfig.getCovidStatsLookupApiHost() + appConfig.getCovidStatsLookupApiEndpoint(),
					CovidApiData.class);
			stopWatch.stop();
			log.info("Covid Stats Lookup Service Execution Times for Host {} and Path {} and Total Time Taken {}",
					appConfig.getCovidStatsLookupApiHost(), appConfig.getCovidStatsLookupApiEndpoint(),
					stopWatch.getTotalTimeMillis());
		} catch (RestClientException exception) {
			throw new ExternalServiceException("covidStatsLookupException-" + exception.getMessage(), exception);

		}
		return covidApiData;
	}

	private boolean isConnectionTimeout(Throwable throwable) {

		boolean isConnectionTimeout = false;
		boolean isUnknownHost = false;
		if (throwable instanceof WebClientRequestException excep) {
			if (excep.contains(ConnectTimeoutException.class)) {
				isConnectionTimeout = true;
			} else if (excep.contains(UnknownHostException.class)) {
				isUnknownHost = true;
			}
		} else {
			isConnectionTimeout = throwable instanceof ConnectTimeoutException;
			isUnknownHost = throwable instanceof UnknownHostException;
		}

		return isConnectionTimeout || isUnknownHost;

	}

}
