package com.praveen.alert.model;

public record SummaryDataResponse(String status, SummaryData data, ErrorMessage errors) {
}
