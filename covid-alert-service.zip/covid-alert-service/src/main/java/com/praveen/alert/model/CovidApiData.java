package com.praveen.alert.model;

import java.time.ZonedDateTime;

public record CovidApiData(CountryData data, ZonedDateTime lastRefreshed, ZonedDateTime lastOriginUpdate) {
}
