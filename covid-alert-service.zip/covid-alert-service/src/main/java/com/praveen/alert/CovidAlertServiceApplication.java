package com.praveen.alert;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestTemplate;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;

@SpringBootApplication
public class CovidAlertServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CovidAlertServiceApplication.class);
	}

	@Bean
	OpenAPI customOpenAPI(Environment env) {

		return new OpenAPI().components(new Components()).info(new Info()
				.title(env.getRequiredProperty("app.openApiTitle"))
				.description(env.getRequiredProperty("app.openApiDescription"))
				.contact(new Contact().name("Praveen Oruganti").email("praveenoruganti@gmail.com")
						.url("https://praveenorugantitech.in"))
				.termsOfService("https://praveenorugantitech.in/about-me")
				.license(new License().name("GNU General Public License v3.0").url("https://www.gnu.org/licenses")));
	}

	@Bean
	RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

}
