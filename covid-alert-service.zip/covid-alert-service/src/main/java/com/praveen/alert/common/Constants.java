package com.praveen.alert.common;

public class Constants {

	// Private constructor to prevent instantiation
	private Constants() {
		throw new UnsupportedOperationException("Constants class cannot be instantiated");
	}

	public static final String INITIAL_REQUEST = "Initial Request";
	public static final String FINAL_RESPONSE = "Final Response";

	public static final String REQUEST = "Request";
	public static final String RESPONSE = "Response";

	public static final String FAIL = "Fail";
	public static final String SUCCESS = "Success";

	public static final String ERROR_RESPONSE = "Error Response";
	public static final String INPUT_VALIDATION_ERROR = "Input Validation Error";
	public static final String INTERNAL_SERVICE_ERROR = "Internal Service Error";
	public static final String EXTERNAL_SERVICE_ERROR = "External Service Error";
}
