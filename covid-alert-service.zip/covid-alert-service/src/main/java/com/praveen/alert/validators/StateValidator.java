package com.praveen.alert.validators;

import com.praveen.alert.enums.StateEnum;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class StateValidator implements ConstraintValidator<State, String> {

	@Override
	public boolean isValid(final String value, final ConstraintValidatorContext context) {
		return StateEnum.isValidStateCode(value);
	}
}
