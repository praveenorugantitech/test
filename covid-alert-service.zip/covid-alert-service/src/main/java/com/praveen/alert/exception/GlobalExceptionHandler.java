package com.praveen.alert.exception;

import static net.logstash.logback.argument.StructuredArguments.kv;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringSubstitutor;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.google.common.collect.Maps;
import com.praveen.alert.common.Constants;
import com.praveen.alert.config.ApplicationConfig;
import com.praveen.alert.exception.ExternalServiceException;
import com.praveen.alert.model.CountryDataResponse;
import com.praveen.alert.model.ErrorMessage;
import com.praveen.alert.model.ValidationError;

import jakarta.validation.ConstraintViolationException;

@RestControllerAdvice
public class GlobalExceptionHandler {

	private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	private ApplicationConfig applicationConfig;

	public GlobalExceptionHandler(ApplicationConfig applicationConfig) {
		this.applicationConfig = applicationConfig;
	}

	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseEntity<CountryDataResponse> handleHttpMessageNotReadableException() {
		Map<String, String> validationErrors = Maps.newHashMap();

		validationErrors.put(applicationConfig.getMessageNotReadableError().code(),
				applicationConfig.getMessageNotReadableError().description());

		CountryDataResponse countryDataResponse = new CountryDataResponse(Constants.FAIL, null,
				new ErrorMessage(applicationConfig.getClientError().code(),
						applicationConfig.getClientError().description(), validationErrors));

		return errorResponse(HttpStatus.BAD_REQUEST, countryDataResponse);

	}

	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	public ResponseEntity<CountryDataResponse> handleHttpMethodNotAllowedException() {
		Map<String, String> validationErrors = Maps.newHashMap();

		validationErrors.put(applicationConfig.getInvalidHttpMethodError().code(),
				applicationConfig.getInvalidHttpMethodError().description());

		CountryDataResponse countryDataResponse = new CountryDataResponse(Constants.FAIL, null,
				new ErrorMessage(applicationConfig.getClientError().code(),
						applicationConfig.getClientError().description(), validationErrors));

		return errorResponse(HttpStatus.METHOD_NOT_ALLOWED, countryDataResponse);

	}

	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<CountryDataResponse> handleValidationErrors(
			ConstraintViolationException constraintViolationException) {
		Map<String, String> validationErrors = Maps.newHashMap();
		constraintViolationException.getConstraintViolations().forEach(violationErrors -> {
			String field = ((PathImpl) violationErrors.getPropertyPath()).getLeafNode().asString().trim();

			List<ValidationError> validationErrorList = applicationConfig.getValidationErrors().get(field.trim());
			validationErrorList.forEach(validationError -> validationErrors.put(validationError.code(),
					replaceTemplateValues(validationError.description())));
		});
		CountryDataResponse countryDataResponse = new CountryDataResponse(Constants.FAIL, null,
				new ErrorMessage(applicationConfig.getClientError().code(),
						applicationConfig.getClientError().description(), validationErrors));

		log.error(Constants.INPUT_VALIDATION_ERROR, kv(Constants.ERROR_RESPONSE, countryDataResponse),
				constraintViolationException);

		return errorResponse(HttpStatus.BAD_REQUEST, countryDataResponse);

	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<CountryDataResponse> handleClientErrors(
			MethodArgumentNotValidException methodArgumentNotValidException) {
		Map<String, String> validationErrors = Maps.newHashMap();

		methodArgumentNotValidException.getBindingResult().getFieldErrors()
				.forEach(fieldError -> populateValidationErrors(validationErrors, fieldError));

		CountryDataResponse countryDataResponse = new CountryDataResponse(Constants.FAIL, null,
				new ErrorMessage(applicationConfig.getClientError().code(),
						applicationConfig.getClientError().description(), validationErrors));

		log.error(Constants.INPUT_VALIDATION_ERROR, kv(Constants.ERROR_RESPONSE, countryDataResponse),
				methodArgumentNotValidException);

		return errorResponse(HttpStatus.BAD_REQUEST, countryDataResponse);
	}

	@ExceptionHandler(ExternalServiceException.class)
	public ResponseEntity<CountryDataResponse> handleExternalServiceException(ExternalServiceException exception) {

		Map<String, String> externalServiceErrors = Maps.newHashMap();
		externalServiceErrors.put(
				applicationConfig.getExternalServiceErrors().get(exception.getMessage().split("-")[0]).code(),
				applicationConfig.getExternalServiceErrors().get(exception.getMessage().split("-")[0]).description()
						+ " " + exception.getMessage().split("-")[1]);

		CountryDataResponse countryDataResponse = new CountryDataResponse(Constants.FAIL, null,
				new ErrorMessage(applicationConfig.getExternalServiceError().code(),
						applicationConfig.getExternalServiceError().description(), externalServiceErrors));

		log.error(Constants.EXTERNAL_SERVICE_ERROR, kv(Constants.ERROR_RESPONSE, countryDataResponse), exception);

		return errorResponse(HttpStatus.INTERNAL_SERVER_ERROR, countryDataResponse);

	}

	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<CountryDataResponse> handleInternalServerError(RuntimeException exception) {

		Map<String, String> serverErrors = Maps.newHashMap();

		serverErrors.put(applicationConfig.getServerErrors().code(),
				applicationConfig.getServerErrors().description() + " " + exception.getMessage());

		CountryDataResponse countryDataResponse = new CountryDataResponse(Constants.FAIL, null,
				new ErrorMessage(applicationConfig.getServerError().code(),
						applicationConfig.getServerError().description(), serverErrors));

		log.error(Constants.INTERNAL_SERVICE_ERROR, kv(Constants.ERROR_RESPONSE, countryDataResponse), exception);

		return errorResponse(HttpStatus.INTERNAL_SERVER_ERROR, countryDataResponse);

	}

	private void populateValidationErrors(Map<String, String> validationErrors, FieldError fieldError) {
		String fieldName = deriveFieldName(fieldError);
		List<ValidationError> validationErrorsList = applicationConfig.getValidationErrors().get(fieldName);
		validationErrorsList.forEach(validationError -> validationErrors.put(validationError.code(),
				replaceTemplateValues(validationError.description())));
	}

	private String deriveFieldName(FieldError fieldError) {
		String fieldName = fieldError.getField();
		if (fieldName.contains(".")) {
			fieldName = StringUtils.substringAfter(fieldName, ".");
		}
		return fieldName;
	}

	private String replaceTemplateValues(String templateMessage) {
		Map<String, String> validationOverrides = Maps.newHashMap();
		StringSubstitutor sub = new StringSubstitutor(validationOverrides);
		return sub.replace(templateMessage);
	}

	private ResponseEntity<CountryDataResponse> errorResponse(HttpStatus status,
			CountryDataResponse countryDataResponse) {
		return ResponseEntity.status(status).body(countryDataResponse);
	}
}