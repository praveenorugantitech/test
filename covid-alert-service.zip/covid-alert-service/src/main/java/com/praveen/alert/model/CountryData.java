package com.praveen.alert.model;

public record CountryData(SummaryData summary, StateData[] regional) {
	
	
}
