package com.praveen.alert.model;

public record BaseDataClass(int confirmedCasesIndian, int confirmedCasesForeign, int discharged, int deaths) {
}
