package com.praveen.alert.model;

public record StateData(BaseDataClass baseData, String loc, int totalConfirmed) {
}
	