package com.praveen.alert.config;

import java.util.concurrent.TimeUnit;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;

import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.resolver.DefaultAddressResolverGroup;
import reactor.netty.http.client.HttpClient;

@Configuration
public class WebClientConfiguration {

	private ApplicationConfig appConfig;

	public WebClientConfiguration(ApplicationConfig appConfig) {
		this.appConfig = appConfig;
	}

	@Bean
	WebClient covidStatsLookup() {
		return WebClient.builder().clientConnector(new ReactorClientHttpConnector(createHttpClient()))
				.baseUrl(appConfig.getCovidStatsLookupApiHost() + appConfig.getCovidStatsLookupApiEndpoint()).build();
	}

	private HttpClient createHttpClient() {
		return HttpClient.newConnection().resolver(DefaultAddressResolverGroup.INSTANCE)
				.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, appConfig.getConnectionTimeout())
				.doOnConnected(connection -> connection
						.addHandlerLast(new ReadTimeoutHandler(appConfig.getReadTimeout(), TimeUnit.MILLISECONDS)));
	}
}