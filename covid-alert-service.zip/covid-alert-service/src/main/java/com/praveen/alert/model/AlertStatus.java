package com.praveen.alert.model;

import java.util.List;

public record AlertStatus(String alertLevel, // RED, GREEN, ORANGE
		List<String> measuresToBeTaken, StateData summaryData) {
}
