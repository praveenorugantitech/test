package com.praveen.alert.model;

import com.praveen.alert.validators.State;

public record StateRequest(@State String stateCode) {

}
