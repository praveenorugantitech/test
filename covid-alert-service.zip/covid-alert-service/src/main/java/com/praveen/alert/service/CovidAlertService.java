package com.praveen.alert.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.praveen.alert.common.Constants;
import com.praveen.alert.enums.StateEnum;
import com.praveen.alert.externalservice.CovidStatsLookupService;
import com.praveen.alert.model.AlertStatus;
import com.praveen.alert.model.AlertStatusResponse;
import com.praveen.alert.model.CountryData;
import com.praveen.alert.model.CountryDataResponse;
import com.praveen.alert.model.CovidApiData;
import com.praveen.alert.model.StateData;
import com.praveen.alert.model.SummaryData;
import com.praveen.alert.model.SummaryDataResponse;

@Service
public class CovidAlertService {

	private final CovidStatsLookupService covidStatsLookupService;

	public CovidAlertService(CovidStatsLookupService covidStatsLookupService) {
		this.covidStatsLookupService = covidStatsLookupService;
	}

	public AlertStatusResponse getAlertAboutState(String stateCode) {
		CovidApiData covidApiData = null;
		covidApiData = covidStatsLookupService.fetchStatsUsingRestTemplate();

		Optional<StateData> optionalStateData = Arrays.stream(covidApiData.data().regional())
				.filter(e -> e.loc().equalsIgnoreCase(StateEnum.getStateNameByCode(stateCode))).findAny();

		StateData stateData = null;
		String alertLevel = "";
		List<String> measuresToBeTaken = List.of();

		if (optionalStateData.isPresent()) {
			stateData = optionalStateData.get();
			if (stateData.totalConfirmed() < 1000) {
				alertLevel = "GREEN";
				measuresToBeTaken = Arrays.asList("Everything is Normal !!");
			} else if (stateData.totalConfirmed() > 1000 && stateData.totalConfirmed() < 50000) {
				alertLevel = "ORANGE";
				measuresToBeTaken = Arrays.asList("Only Essential services are allowed",
						"List of services that come under essential service");
			} else {
				alertLevel = "RED";
				measuresToBeTaken = Arrays.asList("Absolute lock-down",
						"Only Medical and food services are allowed here");
			}
		}

		return new AlertStatusResponse(Constants.SUCCESS, new AlertStatus(alertLevel, measuresToBeTaken, stateData),
				null);

	}

	public SummaryDataResponse getOverAllSummary() {
		CovidApiData covidApiData = covidStatsLookupService.fetchStatsUsingWebClient();
		SummaryData summaryData = covidApiData.data().summary();
		summaryData = summaryData.withUpdateTime(covidApiData.lastRefreshed());
		return new SummaryDataResponse(Constants.SUCCESS, summaryData, null);
	}

	public CountryDataResponse getOverAllStats() {
		CovidApiData covidApiData = covidStatsLookupService.fetchStatsUsingWebClient();
		CountryData countryData = covidApiData.data();
		SummaryData updatedSummary = countryData.summary().withUpdateTime(covidApiData.lastRefreshed());
		countryData = new CountryData(updatedSummary, countryData.regional());

		return new CountryDataResponse(Constants.SUCCESS, countryData, null);
	}
}
