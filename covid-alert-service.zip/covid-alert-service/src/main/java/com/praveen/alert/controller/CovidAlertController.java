package com.praveen.alert.controller;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.praveen.alert.aop.LoggingAspect;
import com.praveen.alert.aop.TrackExecutionTime;
import com.praveen.alert.model.AlertStatusResponse;
import com.praveen.alert.model.CountryDataResponse;
import com.praveen.alert.model.StateRequest;
import com.praveen.alert.model.SummaryDataResponse;
import com.praveen.alert.service.CovidAlertService;
import com.praveen.alert.validators.State;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;

@RestController
@Validated
@Tag(description = "Covid Alert Stats", name = "Covid Alert Stats")
@RequestMapping("/api/v1_0")
public class CovidAlertController {

	private final CovidAlertService alertService;

	public CovidAlertController(CovidAlertService alertService) {
		this.alertService = alertService;
	}

	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/summary/state")
	@Operation(description = "Covid Alert by State", summary = "Covid Alert by State Using Request Param")
	public AlertStatusResponse getAlertAboutStateUsingRequestParam(@RequestParam @State String stateCode) {
		return alertService.getAlertAboutState(stateCode);
	}

	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/summary/state-code/{stateCode}")
	@Operation(description = "Covid Alert by State", summary = "Covid Alert by State Using Path Variable")
	public AlertStatusResponse getAlertAboutStateUsingPathVariable(@PathVariable @State String stateCode) {
		return alertService.getAlertAboutState(stateCode);
	}

	@LoggingAspect
	@TrackExecutionTime
	@PostMapping("/summary/state")
	@Operation(description = "Covid Alert by State", summary = "Covid Alert by State Using Request Body")
	public AlertStatusResponse getAlertAboutStateUsingRequestBody(@Valid @RequestBody StateRequest stateRequest) {
		return alertService.getAlertAboutState(stateRequest.stateCode());
	}

	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/summary")
	@Operation(description = "Covid Alert Overall Summary", summary = "Covid Alert Overall Summary")
	public SummaryDataResponse getOverAllSummary() {
		return alertService.getOverAllSummary();
	}

	@LoggingAspect
	@TrackExecutionTime
	@GetMapping("/stats")
	@Operation(description = "Covid Alert Overall Stats", summary = "Covid Alert Overall Stats")
	public CountryDataResponse getOverAllStats() {
		return alertService.getOverAllStats();
	}
}
