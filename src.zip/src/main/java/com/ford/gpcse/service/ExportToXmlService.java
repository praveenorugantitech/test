package com.ford.gpcse.service;

import com.ford.gpcse.bo.ExportFirwareXmlRequest;
import org.springframework.core.io.Resource;

public interface ExportToXmlService {

    Resource fetchFirmareXml(ExportFirwareXmlRequest exportFirwareXmlRequest);
}
