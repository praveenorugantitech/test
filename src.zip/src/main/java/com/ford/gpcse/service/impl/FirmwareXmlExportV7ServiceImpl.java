package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.ExportFirwareXmlRequest;
import com.ford.gpcse.common.Constants;
import com.ford.gpcse.entity.*;
import com.ford.gpcse.repository.PartFirmwareRepository;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.repository.ProgramDescriptionRepository;
import com.ford.gpcse.service.FirmwareXmlExportV7Service;
import com.ford.gpcse.util.DateFormatterUtility;
import com.ford.gpcse.util.FirmwareXmlExportUtility;
import jakarta.persistence.criteria.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.transform.Transformer;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class FirmwareXmlExportV7ServiceImpl implements FirmwareXmlExportV7Service {
    private final PartRepository partRepository;
    private final ProgramDescriptionRepository programDescriptionRepository;
    private final PartFirmwareRepository partFirmwareRepository;

    @Override
    public Resource generateFirmwareV7Xml(ExportFirwareXmlRequest exportFirwareXmlRequest) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            // Create Document
            Document doc = FirmwareXmlExportUtility.buildDocument();

            // Create root element
            Element rootElement = doc.createElement("PCMReleases");
            rootElement.setAttribute("xmlns", "http://web.pcm.ford.com/Schema/PCMReleaseV7");
            rootElement.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
            rootElement.setAttribute("Version", "7");
            rootElement.setAttribute("ExportedOn", DateFormatterUtility.formatExportedOn(LocalDateTime.now()));
            rootElement.setAttribute("ExportedBy", exportFirwareXmlRequest.getCreateUser());
            rootElement.setAttribute("xsi:schemaLocation", "http://web.pcm.ford.com/Schema/PCMReleaseV7 https://web.pcm.ford.com/Schema/PCMReleaseV7.xsd");
            doc.appendChild(rootElement);

            Specification<Part> spec = buildV7PartSpecification(exportFirwareXmlRequest);
            List<Part> parts = partRepository.findAll(spec);

            // iterating parts
            iteratingV7Parts(parts, doc, rootElement);

            // Write custom XML declaration to the output stream
            String xmlDeclaration = "<?xml version=\"1.0\"?>";
            outputStream.write(xmlDeclaration.getBytes(StandardCharsets.UTF_8));

            // create transformer
            Transformer transformer = FirmwareXmlExportUtility.buildTransformer();

            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(outputStream);
            transformer.transform(source, result);

            return new ByteArrayResource(outputStream.toByteArray());
        } catch (Exception e) {
            log.error("Error occurred while generating Firmware V7 Xml : {}", e.getMessage());
        }
        return null;
    }

    private void iteratingV7Parts(List<Part> parts, Document doc, Element rootElement) {
        for (Part part : parts) {
            Element pcmElement = doc.createElement("PCMRelease");
            rootElement.appendChild(pcmElement);

            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "PartNumber", part.getPartR());
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "ProgramDescription", part.getPartNumX());
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "CatchWord", part.getCatchWordC());
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "CalibrationNumber", part.getCalibR());
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "MainStrategy", part.getStratRelC());
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "ApprovedDate", DateFormatterUtility.dateStringFormat(part.getReldY()));
            if (part.getReldY() != null) {
                pcmElement.setAttribute("xsi:nil", "false");
            } else {
                pcmElement.setAttribute("xsi:nil", "true");
            }
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "Production", "PROT".equals(part.getReleaseUsage().getRelUsgC()) ? "N" : "Y");
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "ConcernNumber", part.getConcernC());
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "ReleaseEngineer", part.getEngineerCdsidC());
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "ModuleType", part.getHardwarePartR());
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "ChipId", part.getChipD());
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "WersNotice", DateFormatterUtility.formatWersNotice(part.getWersNtcR()));
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "SoftwarePartNumber", part.getStratCalibPartR());
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "RomMemorySize", "");
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "MainMicroType", part.getMicroType().getMicroTypX());
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "ServiceModulePartNumber", part.getSvcModulePartR());
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "ServiceModule", "SERV".equals(part.getReleaseUsage().getRelUsgC()) ? "Y" : "N");
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "HcrNumber", part.getHcrR());
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "HardwarePartNumber",  part.getHardwarePartR());
            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "LabelType", part.getLabelUsage()!=null? part.getLabelUsage().getCreateUserC():"");
            Element moduleElement = doc.createElement("Module");
            // Add Code and Description elements
            FirmwareXmlExportUtility.addChildElement(doc, moduleElement, "Code", part.getModuleType().getModuleTypC());
            FirmwareXmlExportUtility.addChildElement(doc, moduleElement, "Description", part.getModuleType().getModuleTypX());
            // Append Module element to pcmElement
            pcmElement.appendChild(moduleElement);

            Element releaseTypeElement = doc.createElement("ReleaseType");
            // Add Code and Description elements
            FirmwareXmlExportUtility.addChildElement(doc, releaseTypeElement, "Code", part.getReleaseType().getRelTypC());
            FirmwareXmlExportUtility.addChildElement(doc, releaseTypeElement, "Description",part.getReleaseType().getRelTypX());
            // Append ReleaseType element to pcmElement
            pcmElement.appendChild(releaseTypeElement);

            Optional<String> peerApprover = part.getPartSignoffs().stream().filter(partSignoff -> partSignoff.getSignoff().getSignoffTypC().equals("PEERR")).map(PartSignoff::getUserCdsidC).distinct().findFirst();

            peerApprover.ifPresent(s -> FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "PeerApprover", s));

            Optional<String> supplierApprover = part.getPartSignoffs().stream().filter(partSignoff -> partSignoff.getSignoff().getSignoffTypC().equals("SUPPR")).map(PartSignoff::getUserCdsidC).distinct().findFirst();

            supplierApprover.ifPresent(s -> FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "SupplierApprover", s));

            FirmwareXmlExportUtility.addChildElement(doc, pcmElement, "SupplierApprover", "");


            Specification<ProgramDescription> programDescriptionSpecification = findByV7PartR(part.getPartR());

            List<ProgramDescription> programDescriptions = programDescriptionRepository.findAll(programDescriptionSpecification);

            if (!programDescriptions.isEmpty()) {
                // iterating program descriptions
                iteratingV7ProgramDescriptions(programDescriptions, doc, rootElement, part);
            }

            Specification<PartFirmware> partFirmwareSpecification = findByV7PartRAndApproved(part.getPartR());
            List<PartFirmware> partFirmwares = partFirmwareRepository.findAll(partFirmwareSpecification);

            if (!partFirmwares.isEmpty()) {
                // iterating firmwares
                iteratingV7PartFirmwares(partFirmwares, doc, rootElement);
            }
        }
    }

    private void iteratingV7ProgramDescriptions(List<ProgramDescription> programDescriptions, Document doc, Element rootElement, Part part) {
        for (ProgramDescription programDescription : programDescriptions) {
            Element applicationElement = doc.createElement("Application");
            rootElement.appendChild(applicationElement);

            FirmwareXmlExportUtility.addChildElement(doc, applicationElement, "ID", String.valueOf(programDescription.getPgmK()));
            FirmwareXmlExportUtility.addChildElement(doc, applicationElement, "ModelYear", programDescription.getMdlYrR());
            FirmwareXmlExportUtility.addChildElement(doc, applicationElement, "Program", programDescription.getPgmN());
            FirmwareXmlExportUtility.addChildElement(doc, applicationElement, "Platform", programDescription.getPlatN());
            FirmwareXmlExportUtility.addChildElement(doc, applicationElement, "Engine", programDescription.getEngN());
            FirmwareXmlExportUtility.addChildElement(doc, applicationElement, "Transmission", programDescription.getTransN());
            FirmwareXmlExportUtility.addChildElement(doc, applicationElement, "Supplier", part.getSupplier().getSuplX());
        }
    }


    private void iteratingV7PartFirmwares(List<PartFirmware> partFirmwares, Document doc, Element rootElement) {
        for (PartFirmware partFirmware : partFirmwares) {
            Element firmwareElement = doc.createElement("Firmware");
            rootElement.appendChild(firmwareElement);

            FirmwareXmlExportUtility.addChildElement(doc, firmwareElement, "ID", String.valueOf(partFirmware.getFirmware().getFirmwareK()));
            FirmwareXmlExportUtility.addChildElement(doc, firmwareElement, "Description", partFirmware.getFirmware().getFirmwareN());
            FirmwareXmlExportUtility.addChildElement(doc, firmwareElement, "Value", partFirmware.getFileN());
            FirmwareXmlExportUtility.addChildElement(doc, firmwareElement, "ApprovedBy", partFirmware.getAprvdByCdsidC());
            FirmwareXmlExportUtility.addChildElement(doc, firmwareElement, "ApprovedDate", DateFormatterUtility.dateStringFormat(partFirmware.getAprvdY()));
        }
    }

    private Specification<PartFirmware> findByV7PartRAndApproved(String partR) {
        return (Root<PartFirmware> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) -> {
            // Create joins
            Join<PartFirmware, Firmware> firmwareJoin = root.join("firmware");
            Join<PartFirmware, Part> partJoin = root.join("part");

            // Define predicates
            Predicate partRPredicate = criteriaBuilder.equal(partJoin.get(Constants.PART_R), partR);
            Predicate approvedPredicate = criteriaBuilder.isNotNull(root.get("aprvdY"));
            Predicate firmwareJoinPredicate = criteriaBuilder.equal(root.get("firmware").get(Constants.FIRMWARE_K), firmwareJoin.get(Constants.FIRMWARE_K));

            // Combine the predicates
            assert query != null;
            query.where(criteriaBuilder.and(
                    firmwareJoinPredicate,
                    partRPredicate,
                    approvedPredicate
            ));

            // Add ordering
            query.orderBy(criteriaBuilder.asc(firmwareJoin.get("firmwareN")));

            // Selecting specific fields
            query.multiselect(
                    firmwareJoin.get("firmwareN"),
                    root.get("fileN"),
                    root.get("aprvdByCdsidC"),
                    root.get("aprvdY"),
                    firmwareJoin.get(Constants.FIRMWARE_K)
            );

            return query.getRestriction();
        };
    }

    private Specification<ProgramDescription> findByV7PartR(String partR) {
        return (Root<ProgramDescription> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) -> {
            // Create a subquery for the ProgramPart entity
            assert query != null;
            Subquery<Long> subquery = query.subquery(Long.class);
            Root<ProgramPart> programPartRoot = subquery.from(ProgramPart.class);

            // Join to Part entity
            Join<ProgramPart, Part> programPartToPart = programPartRoot.join("part");

            // Subquery criteria
            subquery.select(programPartRoot.get("pgmK"))
                    .where(criteriaBuilder.equal(programPartToPart.get(Constants.PART_R), partR));

            // Main query criteria
            return criteriaBuilder.in(root.get("pgmK")).value(subquery);
        };
    }

    private Specification<Part> buildV7PartSpecification(ExportFirwareXmlRequest request) {
        return (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            // Always include these base conditions
            predicates.add(criteriaBuilder.equal(root.get("archF"), "N"));
            predicates.add(criteriaBuilder.not(root.get("statC").in("NewPnRequest", "PeadEdit", "PeadComplete")));

            // Add conditions based on ExportFirwareXmlRequest
            if (request.getPartR() != null && !request.getPartR().isEmpty()) {
                predicates.add(root.get(Constants.PART_R).in(request.getPartR()));
            }

            if (request.getConcernC() != null && !request.getConcernC().isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("concernC"), request.getConcernC()));
            }

            if (request.getWersNtcR() != null && !request.getWersNtcR().isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("wersNtcR"), request.getWersNtcR()));
            }

            // Joins based on SQL query
            Join<Part, ModuleType> moduleTypeJoin = root.join("moduleType", JoinType.INNER);
            Join<Part, Supplier> supplierJoin = root.join("supplier", JoinType.LEFT);
            Join<Part, MicroType> microTypeJoin = root.join("microType", JoinType.LEFT);

            // Subqueries to fetch additional data
            assert query != null;
            Subquery<String> labelTypeSubquery = query.subquery(String.class);
            Root<LabelUsg> labelUsageRoot = labelTypeSubquery.from(LabelUsg.class);
            labelTypeSubquery.select(labelUsageRoot.get("createUserC"))
                    .where(criteriaBuilder.equal(labelUsageRoot.get("labelUsgK"), root.get("labelUsage").get("labelUsgK")));

            Subquery<String> peerReviewCdsSubquery = query.subquery(String.class);
            Root<PartSignoff> peerReviewRoot = peerReviewCdsSubquery.from(PartSignoff.class);
            peerReviewCdsSubquery.select(peerReviewRoot.get("userCdsidC"))
                    .where(criteriaBuilder.equal(peerReviewRoot.get("part"), root),
                            criteriaBuilder.equal(peerReviewRoot.get("signoffTypC"), "PEERR"));

            Subquery<String> supReviewCdsSubquery = query.subquery(String.class);
            Root<PartSignoff> supReviewRoot = supReviewCdsSubquery.from(PartSignoff.class);
            supReviewCdsSubquery.select(supReviewRoot.get("userCdsidC"))
                    .where(criteriaBuilder.equal(supReviewRoot.get("part"), root),
                            criteriaBuilder.equal(supReviewRoot.get("signoffTypC"), "SUPPR"));

            // Adding selected fields to the query
            query.multiselect(
                    root.get(Constants.PART_R),
                    root.get("partNumX"),
                    root.get("catchWordC"),
                    root.get("calibR"),
                    root.get("stratRelC"),
                    root.get("reldY"),
                    root.get("concernC"),
                    root.get("engineerCdsidC"),
                    root.get("hardwarePartR"),
                    root.get("chipD"),
                    root.get("wersNtcR"),
                    root.get("stratCalibPartR"),
                    supplierJoin.get("suplX"),
                    microTypeJoin.get("microTypX"),
                    moduleTypeJoin.get("moduleTypC"),
                    moduleTypeJoin.get("moduleTypX"),
                    root.get("hcrR"),
                    root.get("svcModulePartR"),
                    labelTypeSubquery,
                    peerReviewCdsSubquery,
                    supReviewCdsSubquery,
                    root.get("releaseUsage"),
                    root.get("releaseType")
            );

            // Adding order
            query.orderBy(criteriaBuilder.asc(root.get(Constants.PART_R)));

            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }


}



