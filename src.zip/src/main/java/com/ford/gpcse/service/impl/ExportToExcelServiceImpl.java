package com.ford.gpcse.service.impl;

import com.ford.gpcse.repository.FirmwareRepository;
import com.ford.gpcse.repository.PartFirmwareRepository;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.service.ExportToExcelService;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class ExportToExcelServiceImpl implements ExportToExcelService {

    private final PartRepository partRepository;
    private final PartFirmwareRepository partFirmwareRepository;
    private final FirmwareRepository firmwareRepository;

    private static final String[] HEADERS = {
            "Part Number", "Firmware Program", "MY", "Program", "Platform",
            "Engine", "Transmission", "Lineage", "Release Type", "Release Usage",
            "Calib. No.", "Cal Variant", "Cal R Level", "Catch Word", "Release Eng.",
            "Hardware PN", "Core Hardware PN", "Core Hardware Owner", "Main Micro Type",
            "Supplier", "HCR Number", "Software PN", "Calibration PN", "Main Strategy",
            "Chip ID", "Build Level", "Release Priority", "Release Priority Details",
            "Concern", "WERS Notice", "WERS Description", "Backwards Compatibility",
            "Replaced P/N", "IPF Module P/N", "Service Module PN",
            "Reason for not Backwards Compatible", "Superseded",
            "Application Peer Reviewer", "Hardware Peer Reviewer",
            "Project Control Engineer", "Calibrator",
            "Assembly Peer Reviewer", "Label Type", "IVS Program",
            "Date Created", "Cal Date Planned", "Cal Date Actual",
            "Date Locked", "Release Status", "IVS Service Action"
    };

    @Override
    public ByteArrayInputStream exportPartsBasedOnPartNumbers(List<String> partNumbers) throws IOException {
        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("ExportFirmwareVertical");
            int totalNumberOfHeaderColumns = createHeaderRow(sheet, partNumbers);

            List<Object[]> partResults = partRepository.findAllPartsByIds(partNumbers);
            List<Object[]> firmwareResults = partFirmwareRepository.findAllFirmwareByParts(partNumbers);

            // Check for nulls and initialize empty lists if needed
            if (partResults == null) {
                partResults = List.of();
            }
            if (firmwareResults == null) {
                firmwareResults = List.of();
            }

            Map<String, String> firmwareMap = populateFirwareMap(firmwareResults);
            // Write the results to the sheet
            int rowNum = 1;
            for (Object[] partResult : partResults) {
                if (partResult != null) {
                    Row row = sheet.createRow(rowNum++); // Create a new row
                    createDataRow(partResult, row, firmwareMap, totalNumberOfHeaderColumns);

                }
            }

            workbook.write(out);
            return new ByteArrayInputStream(out.toByteArray());
        }
    }

    private static void createDataRow(Object[] partResult, Row row, Map<String, String> firmwareMap, int totalNumberOfHeaderColumns) {
        row.createCell(0).setCellValue(partResult[0] != null ? partResult[0].toString() : ""); // PCMR01_PART_R
        String firmwareProgram =
                (partResult[45] != null ? partResult[45].toString() : "") + "," +  // PCMS01_MDL_YR_R
                        (partResult[46] != null ? partResult[46].toString() : "") + "," + // PCMS01_PGM_N
                        (partResult[47] != null ? partResult[47].toString() : "") + "," + // PCMS01_PLAT_N
                        (partResult[48] != null ? partResult[48].toString() : "") + "," + // PCMS01_ENG_N
                        (partResult[49] != null ? partResult[49].toString() : ""); // PCMS01_TRANS_N

        row.createCell(1).setCellValue(firmwareProgram); // Firmware Program
        row.createCell(2).setCellValue(partResult[45] != null ? partResult[45].toString() : ""); // PCMS01_MDL_YR_R
        row.createCell(3).setCellValue(partResult[46] != null ? partResult[46].toString() : ""); // PCMS01_PGM_N
        row.createCell(4).setCellValue(partResult[47] != null ? partResult[47].toString() : ""); // PCMS01_PLAT_N
        row.createCell(5).setCellValue(partResult[48] != null ? partResult[48].toString() : ""); // PCMS01_ENG_N
        row.createCell(6).setCellValue(partResult[49] != null ? partResult[49].toString() : ""); // PCMS01_TRANS_N
        row.createCell(7).setCellValue(partResult[1] != null ? partResult[1].toString() : "");   // PCMR01_PART_NUM_X
        row.createCell(8).setCellValue(partResult[21] != null ? partResult[21].toString() : ""); // PCMR15_REL_TYP_X
        row.createCell(9).setCellValue(partResult[16] != null ? partResult[16].toString() : ""); // PCMR24_REL_USG_X
        row.createCell(10).setCellValue(partResult[3] != null ? partResult[3].toString() : "");  // PCMR01_CALIB_R
        row.createCell(11).setCellValue(partResult[4] != null ? partResult[4].toString() : "");  // Cal Variant
        row.createCell(12).setCellValue(partResult[5] != null ? partResult[5].toString() : "");  // Cal R Level
        row.createCell(13).setCellValue(partResult[2] != null ? partResult[2].toString() : "");  // PCMR01_CATCHWORD_C
        row.createCell(14).setCellValue(partResult[9] != null ? partResult[9].toString() : "");  // PCMR01_ENGINEER_CDSID_C
        row.createCell(15).setCellValue(partResult[10] != null ? partResult[10].toString() : ""); // PCMR01_HARDWARE_PART_R
        row.createCell(16).setCellValue(partResult[43] != null ? partResult[43].toString() : ""); // PCMR01_CORE_HARDWARE_PART_R
        row.createCell(17).setCellValue(partResult[44] != null ? partResult[44].toString() : ""); // PCMR01_CORE_HARDWARE_CDSID_C
        row.createCell(18).setCellValue(partResult[14] != null ? partResult[14].toString() : ""); // PCMR19_MICRO_TYP_X
        row.createCell(19).setCellValue(partResult[20] != null ? partResult[20].toString() : ""); // PCMR17_SUPL_X
        row.createCell(20).setCellValue(partResult[15] != null ? partResult[15].toString() : ""); // PCMR01_HCR_R
        row.createCell(21).setCellValue(partResult[13] != null ? partResult[13].toString() : ""); // PCMR01_STRAT_CALIB_PART_R
        row.createCell(22).setCellValue(partResult[29] != null ? partResult[29].toString() : ""); // PCMR01_STRAT_PART_R
        row.createCell(23).setCellValue(partResult[6] != null ? partResult[6].toString() : "");   // PCMR01_STRAT_REL_C
        row.createCell(24).setCellValue(partResult[11] != null ? partResult[11].toString() : ""); // PCMR01_CHIP_D
        row.createCell(25).setCellValue(partResult[32] != null ? partResult[32].toString() : ""); // PCMR01_BLD_LVL_C
        row.createCell(26).setCellValue(partResult[33] != null ? partResult[33].toString() : ""); // PCMR01_PRTY_C
        row.createCell(27).setCellValue(partResult[34] != null ? partResult[34].toString() : ""); // PCMR01_PRTY_DTL_X
        row.createCell(28).setCellValue(partResult[8] != null ? partResult[8].toString() : "");   // PCMR01_CONCERN_C
        row.createCell(29).setCellValue(partResult[12] != null ? formatNotice(partResult[12].toString()) : ""); // PCMR01_WERS_NTC_R
        row.createCell(30).setCellValue(partResult[28] != null ? partResult[28].toString() : ""); // PCMR01_CMT_X
        row.createCell(31).setCellValue(partResult[22] != null ? partResult[22].toString() : ""); // PCMR26_BACKWARD_COMPAT_X
        row.createCell(32).setCellValue(partResult[23] != null ? partResult[23].toString() : ""); // PCMR01_REPLACED_PART_R
        row.createCell(33).setCellValue(partResult[24] != null ? partResult[24].toString() : ""); // PCMR01_IPF_PART_R
        row.createCell(34).setCellValue(partResult[17] != null ? partResult[17].toString() : ""); // PCMR01_SVC_MODULE_PART_R
        row.createCell(35).setCellValue(partResult[25] != null ? partResult[25].toString() : ""); // PCMR01_BACKWARD_COMPAT_GRP_C
        row.createCell(36).setCellValue(partResult[37] != null ? partResult[37].toString() : ""); // Superseded
        row.createCell(37).setCellValue(partResult[38] != null ? partResult[38].toString() : ""); // Application Peer Reviewer
        row.createCell(38).setCellValue(partResult[36] != null ? partResult[36].toString() : ""); // Hardware Peer Reviewer
        row.createCell(39).setCellValue(partResult[35] != null ? partResult[35].toString() : ""); // PCMR01_PROJ_CTL_ENG_CDSID_C
        row.createCell(40).setCellValue(partResult[26] != null ? partResult[26].toString() : ""); // PCMR01_PWRTRN_CALIB_CDSID_C
        row.createCell(41).setCellValue(partResult[30] != null ? partResult[30].toString() : ""); // Assembly Peer Reviewer
        row.createCell(42).setCellValue(partResult[19] != null ? partResult[19].toString() : ""); // Label Type
        row.createCell(43).setCellValue(partResult[31] != null ? partResult[31].toString() : ""); // PCMS01_IVS_PGM_D
        row.createCell(44).setCellValue(partResult[50] != null ? partResult[50].toString() : ""); // PCMR01_CONCERN_Y
        row.createCell(45).setCellValue(partResult[18] != null ? partResult[18].toString() : ""); // PCMR01_CAL_REL_PLAN_Y
        row.createCell(46).setCellValue(partResult[51] != null ? partResult[51].toString() : ""); // PCMR01_CAL_REL_ACT_Y
        row.createCell(47).setCellValue(partResult[7] != null ? partResult[7].toString() : "");   // PCMR01_RELD_Y
        row.createCell(48).setCellValue(partResult[27] != null ? releaseStatusText(partResult[27].toString()) : ""); // PCMR01_STAT_C
        row.createCell(49).setCellValue("");   // PCMR04_IVS_SERVICE_ACTION_R column not found in WPCMR04_PGM_PART table

        createFirmwareCellData(partResult, firmwareMap, totalNumberOfHeaderColumns, row);
    }

    private static void createFirmwareCellData(Object[] partResult, Map<String, String> firmwareMap, int totalNumberOfHeaderColumns, Row row) {
        // logic for firmware data columns
        // Retrieve the concatenated firmware values for the current part number
        String partNumber = partResult[0] != null ? partResult[0].toString() : "";
        String firmwareData = firmwareMap.getOrDefault(partNumber, ""); // Default to empty if not found

        if (firmwareData != null && !firmwareData.isEmpty() && !firmwareData.isBlank()) {
            String[] firmwareDataArray = firmwareData.split(",");
            int totalNumberofPendingColumnValues = totalNumberOfHeaderColumns - 50;
            if (firmwareDataArray.length == totalNumberofPendingColumnValues) {
                for (int i = 0; i < totalNumberofPendingColumnValues; i++) {
                    row.createCell(50 + i).setCellValue(firmwareDataArray[i]);
                }
            }


        }
    }

    private static Map<String, String> populateFirwareMap(List<Object[]> firmwareResults) {
        // Use a map to associate part numbers with their firmware data
        Map<String, String> firmwareMap = new HashMap<>();

        // Populate the firmwareMap with concatenated firmware and file names
        for (Object[] firmwareResult : firmwareResults) {
            if (firmwareResult != null && firmwareResult.length >= 3) {
                String partNumber = firmwareResult[0] != null ? firmwareResult[0].toString() : "";
                String fileName = firmwareResult[2] != null ? firmwareResult[2].toString() : "";

                String currentValue = firmwareMap.getOrDefault(partNumber, "");
                if (!currentValue.isEmpty()) {
                    currentValue += ","; // Add a comma if there's already a value
                }
                currentValue += fileName; // Concatenate firmware and file name
                firmwareMap.put(partNumber, currentValue);
            }
        }
        return firmwareMap;
    }

    private static String releaseStatusText(String releaseStatusCode) {
        return switch (releaseStatusCode) {
            case "NewPnRequest" -> "New Part Number Request";
            case "PeadEdit", "PeadComplete" -> "Module Base Info Edit";
            case "FirmwareEdit" -> "Firmware Edit";
            case "SoftLock" -> "Soft Lock";
            case "HardLock" -> "Hard Lock";
            case "Complete" -> "Release Complete";
            default -> "";
        };
    }


    private int createHeaderRow(Sheet sheet, List<String> partNumbers) {
        Row headerRow = sheet.createRow(0);
        headerRow.setHeightInPoints(20);

        // Create a font for the header and set it to bold
        Workbook workbook = sheet.getWorkbook();
        CellStyle headerStyle = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        headerStyle.setFont(font);

        // Create static headers first
        int columnIndex = 0;
        for (String header : HEADERS) {
            Cell cell = headerRow.createCell(columnIndex);
            cell.setCellValue(header);
            cell.setCellStyle(headerStyle); // Apply the bold style

            // Set the column width based on the header length
            int columnWidth = header.length() * 512;
            sheet.setColumnWidth(columnIndex, columnWidth);
            columnIndex++;
        }

        // Fetch firmware column headers based on part numbers
        List<Object[]> firmwareHeaders = firmwareRepository.findFirmwareColumnHeaders(partNumbers);

        // Create dynamic headers based on fetched Firmware_N values
        for (Object[] row : firmwareHeaders) {
            String firmwareName = (String) row[1]; // PCM03_FIRMWARE_N

            Cell cell = headerRow.createCell(columnIndex);
            cell.setCellValue(firmwareName);
            cell.setCellStyle(headerStyle); // Apply the bold style

            // Set the column width based on the header length
            int columnWidth = firmwareName.length() * 512;
            sheet.setColumnWidth(columnIndex, columnWidth);
            columnIndex++;
        }

        // Return the total number of columns
        return columnIndex; // This will be the total number of headers
    }


    private static String formatNotice(String notice) {
        if (notice.length() == 16) {
            return String.format("%s %s %s %s",
                    notice.substring(0, 4),
                    notice.charAt(4),
                    notice.substring(5, 13),
                    notice.substring(13, 16));
        }

        return notice;
    }


}
