package com.ford.gpcse.service;

import com.ford.gpcse.bo.ExportFirwareXmlRequest;
import org.springframework.core.io.Resource;

public interface FirmwareXmlExportV6Service {
    Resource generateFirmwareV6Xml(ExportFirwareXmlRequest exportFirwareXmlRequest);
}
