package com.ford.gpcse.service;

import com.ford.gpcse.bo.ExportFirwareXmlRequest;
import org.springframework.core.io.Resource;

public interface FirmwareXmlExportV5Service {
    Resource generateFirmwareV5Xml(ExportFirwareXmlRequest exportFirwareXmlRequest);
}
