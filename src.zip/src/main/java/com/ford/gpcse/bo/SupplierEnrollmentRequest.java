package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SupplierEnrollmentRequest {
    private String userId;
    private String firstName;
    private String lastName;
    private String emailAddress;
    private String comments;
}
