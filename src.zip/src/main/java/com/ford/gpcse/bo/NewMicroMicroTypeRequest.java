package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class NewMicroMicroTypeRequest {
    private String mainMicroTypeName;
    private String createUser;
    private String lastUpdateUser;
    private String moduleTypeCode;
    private String supplierCode;
    private String supplierName;
}
