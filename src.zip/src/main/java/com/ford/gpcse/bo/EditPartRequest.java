package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class EditPartRequest {

    private List<String> partNumbers;
    private String softwarePN;
    private String catchWord;
    private String concernNumber;
    private String calibrationNum;
    private String wersConcernDescription;
    private String appEng;
    private String comments;
    private String buildLevel;
    private String releasePriority;
    private String releasePriorityDetail;
}
