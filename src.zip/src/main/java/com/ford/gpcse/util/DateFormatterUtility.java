package com.ford.gpcse.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;

public class DateFormatterUtility {

    // Private constructor to prevent instantiation
    private DateFormatterUtility() {
        throw new UnsupportedOperationException("Utility class cannot be instantiated");
    }

    public static String dateTimeStringInYYMMDD(LocalDate date) {
        // Define the pattern for formatting
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyMMdd");

        // Format the LocalDate object to the desired pattern and return
        return date.format(formatter);
    }

    public static String dateTimeStringConcern(LocalDate pDate) {
        // Get the last two digits of the year
        String yearPart = String.format("%02d", pDate.getYear() % 100);

        // Get the month part with leading zero if needed
        String monthPart = String.format("%02d", pDate.getMonthValue());

        // Get the day part with leading zero if needed
        String dayPart = String.format("%02d", pDate.getDayOfMonth());

        // Concatenate all parts and return the result
        return yearPart + monthPart + dayPart;
    }

    public static String dateTimeStringNewPart(LocalDateTime pDate) {
        // Format each part of the date-time with leading zeros if necessary
        String monthPart = String.format("%02d", pDate.getMonthValue());
        String dayPart = String.format("%02d", pDate.getDayOfMonth());
        String hourPart = String.format("%02d", pDate.getHour());
        String minutePart = String.format("%02d", pDate.getMinute());
        String secondPart = String.format("%02d", pDate.getSecond());

        // Concatenate all parts and return the result
        return monthPart + dayPart + hourPart + minutePart + secondPart;
    }

    public static String formatDateMonthAbr(LocalDate date) {
        if (date != null) {
            // Define the desired output format
            DateTimeFormatter outputFormatter = new DateTimeFormatterBuilder()
                    .appendPattern("MMM d, yyyy")
                    .toFormatter();
            // Format and return the date
            return date.format(outputFormatter);
        } else {
            return " "; // Handle null case as needed
        }
    }


    public static String dateTimeStringNotice(LocalDateTime pDate) {
        // Formatter to format the date as per the logic
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyMMddHHmm");

        // Format the LocalDateTime to the required string format
        return pDate.format(formatter);
    }

    public static String dateTimeStringFormatFilename(LocalDateTime dateTime) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd-HHmm");
        return dateTime.format(formatter);
    }

//    public static String dateTimeStringFormat(LocalDateTime dateTime) {
//        if (dateTime != null) {
//            DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
//            String strTime = dateTime.format(timeFormatter);
//
//            if (strTime.equals("00:00:00")) {
//                return dateTime.toLocalDate().toString(); // Format as "YYYY-MM-DD"
//            } else {
//                return dateTime.toLocalDate().toString() + " " + strTime;
//            }
//        }
//        return null; // or an empty string, depending on your preference
//    }

    public static String dateStringFormat(LocalDate date) {
        if (date != null) {
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            return date.format(dateFormatter); // Format as "YYYY-MM-DD"
        }
        return null; // or an empty string, depending on your preference
    }

    public static String formatWersNotice(String wersNotice) {
        if (wersNotice != null && wersNotice.length() == 16) {
            return wersNotice.substring(0, 4).toUpperCase() + " " +
                    wersNotice.charAt(4) + " " +
                    wersNotice.substring(5, 13) + " " +
                    wersNotice.substring(13);
        }
        return wersNotice != null ? wersNotice : "";
    }

    public static String dateTimeXmlFormat(LocalDateTime pDateTime) {
        if (pDateTime != null) {
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

            String strTime = timeFormatter.format(pDateTime);

            // Check if time is "00:00:00"
            if ("00:00:00".equals(strTime)) {
                return dateFormatter.format(pDateTime);
            } else {
                return dateFormatter.format(pDateTime) + "T" + strTime;
            }
        } else {
            return null; // Handle null case as needed
        }
    }

    public static String formatExportedOn(LocalDateTime dateTime) {
        // Define the desired date format pattern
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss");
        // Format the LocalDateTime and return the result
        return dateTime.format(formatter);
    }

}
