package com.ford.gpcse.repository;

import com.ford.gpcse.entity.ReleaseRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReleaseRequestRepository extends JpaRepository<ReleaseRequest, Long>, JpaSpecificationExecutor<ReleaseRequest> {

    List<ReleaseRequest> findAllByOrderByRelReqKDesc();
}
