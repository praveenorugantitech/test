package com.ford.gpcse.repository;

import com.ford.gpcse.entity.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SupplierRepository extends JpaRepository<Supplier, String> {

    @Query("SELECT s FROM Supplier s WHERE s.archF = 'N' ORDER BY s.suplX")
    List<Supplier> fetchActiveSuppliers();

   Supplier findBySuplC(String supplierCode);



}
