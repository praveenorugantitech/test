package com.ford.gpcse.repository;

import com.ford.gpcse.common.Constants;
import com.ford.gpcse.dto.*;
import com.ford.gpcse.entity.Part;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Repository
public interface PartRepository extends JpaRepository<Part, String>, JpaSpecificationExecutor<Part> {


    @Query("SELECT p.supplier.suplC FROM Part p WHERE p.partR = :partNumber")
    String fetchSupplierBasedOnPartNumber(@Param("partNumber") String partNumber);

    @Query("SELECT p.pwrtrnCalibCdsidC FROM Part p WHERE p.partR = :partR")
    String fetchCalibrationCodeByPartR(@Param("partR") String partR);

    @Query("SELECT new com.ford.gpcse.dto.ReplaceSblPartDetailsDto(p.moduleType.moduleTypC, "
            + "p.microType.microTypC, p.supplier.suplC, "
            + "(SELECT COUNT(sub) FROM Part sub WHERE sub.partR = :newPartNumber)) "
            + "FROM Part p WHERE p.partR = :oldPartNumber")
    List<ReplaceSblPartDetailsDto> fetchPartDetails(@Param("oldPartNumber") String oldPartNumber,
                                                    @Param("newPartNumber") String newPartNumber);

    @Query("SELECT new com.ford.gpcse.dto.PartFirwareDto(p.partR, p.partNumX, p.calibPartR, p.stratRelC, "
            + "p.engineerCdsidC, p.hardwarePartR, mt.microTypX, p.chipD, p.stratCalibPartR, p.catchWordC, "
            + "p.releaseUsage, p.releaseType, p.stratPartR, p.cmtX, p.coreHardwarePartR, p.concernC) "
            + "FROM Part p "
            + "JOIN p.releaseType rt "
            + "JOIN p.moduleType m "
            + "LEFT JOIN p.microType mt "
            + "WHERE rt.relTypC IN :hardwareReleaseTypes "
            + "AND p.partR IN (SELECT pf.part.partR FROM PartFirmware pf WHERE pf.fileN = :mCurrentPbl) "
            + "AND p.reldF = 'Y' "
            + "ORDER BY mt.microTypX, p.hardwarePartR")
    List<PartFirwareDto> fetchPartsByFirmware(@Param("mCurrentPbl") String mCurrentPbl,
                                              @Param("hardwareReleaseTypes") List<String> hardwareReleaseTypes);


    @Query("SELECT new com.ford.gpcse.dto.FirmwareDto(p.partR, p.partNumX, p.calibPartR, p.stratRelC, "
            + "p.engineerCdsidC, p.hardwarePartR, mt.microTypX, p.chipD, p.stratCalibPartR, p.catchWordC, "
            + "ru.relUsgX, r.relTypX, p.wersNtcR, p.concernC, p.cmtX, p.pwrtrnCalibCdsidC, "
            + "s.suplX, p.coreHardwareCdsidC, p.coreHardwarePartR) " + "FROM Part p " + "JOIN p.releaseType r " + "JOIN p.releaseUsage ru " + "JOIN p.moduleType m "
            + "LEFT JOIN p.microType mt " + "LEFT JOIN p.supplier s " + "WHERE p.statC IS NOT NULL "
            + "AND p.concernC = :wersConcern " + "ORDER BY r.relTypX, ru.relUsgX, p.concernC DESC, p.cmtX, p.partR")
    List<FirmwareDto> fetchFirmwareDetailsByWersConcern(@Param("wersConcern") String wersConcern);

    @Query("SELECT new com.ford.gpcse.dto.FirmwareDto(p.partR, p.partNumX, p.calibPartR, p.stratRelC, "
            + "p.engineerCdsidC, p.hardwarePartR, mt.microTypX, p.chipD, p.stratCalibPartR, p.catchWordC, "
            + "ru.relUsgX, r.relTypX, p.wersNtcR, p.concernC, p.cmtX, p.pwrtrnCalibCdsidC, "
            + "s.suplX, p.coreHardwareCdsidC, p.coreHardwarePartR) " + "FROM Part p " + "JOIN p.releaseType r " + "JOIN p.releaseUsage ru " + "JOIN p.moduleType m "
            + "LEFT JOIN p.microType mt " + "LEFT JOIN p.supplier s " + "WHERE p.statC IS NOT NULL "
            + "AND p.wersNtcR LIKE :wersNotice "
            + "ORDER BY r.relTypX, ru.relUsgX, p.concernC DESC, p.cmtX, p.partR")
    List<FirmwareDto> fetchFirmwareDetailsByWersNotice(@Param("wersNotice") String wersNotice);


    @Query("SELECT new com.ford.gpcse.dto.FirmwareDto(tblSoftRel.partR, tblSoftRel.partNumX, " +
            "tblSoftRel.calibR, tblSoftRel.stratRelC, tblSoftRel.engineerCdsidC, " +
            "tblSoftRel.hardwarePartR, tblMM.microTypX, tblSoftRel.chipD, " +
            "tblSoftRel.stratCalibPartR, tblSoftRel.catchWordC, ru.relUsgC, " +
            "rt.relTypC, tblSoftRel.wersNtcR, tblSoftRel.concernC, " +
            "tblSoftRel.cmtX, tblSoftRel.pwrtrnCalibCdsidC, tblSup.suplX, tblMM.microTypOwnrCdsidC, " +
            "tblSoftRel.coreHardwarePartR) " +
            "FROM Part tblSoftRel " +
            "INNER JOIN tblSoftRel.moduleType tblModType " +
            "LEFT JOIN tblSoftRel.microType tblMM " +
            "LEFT JOIN tblSoftRel.supplier tblSup " +
            "LEFT JOIN tblSoftRel.releaseUsage ru " +
            "LEFT JOIN tblSoftRel.releaseType rt " +
            "WHERE tblSoftRel.statC IS NOT NULL " +
            "AND tblSoftRel.partR IN ( " +
            "SELECT tblProgramPart.part.partR " +
            "FROM ProgramDescription tblProgramDesc " +
            "INNER JOIN ProgramPart  tblProgramPart " +
            "ON tblProgramDesc.pgmK = tblProgramPart.pgmK " +
            "WHERE tblProgramDesc.pgmK IN :programKeys OR tblProgramDesc.pgmK = -999998) " +
            "ORDER BY rt.relTypC, ru.relUsgC, tblSoftRel.concernC DESC, tblSoftRel.cmtX, tblSoftRel.partR")
    List<FirmwareDto> fetchFirmwareDetailsByPrograms(@Param("programKeys") List<Long> programKeys);

    @Query("SELECT DISTINCT  new com.ford.gpcse.dto.ReleaseStatusDto(p.concernC, p.partR, p.statC, m.moduleTypX, r.relTypX, p.concernY)" + "FROM Part p "
            + "JOIN p.supplier sup " + "JOIN p.moduleType m " + "JOIN p.releaseType r " + "WHERE p.archF = 'N' "
            + "AND r.relTypC NOT IN ('HRDCN', 'HWPUT', 'VCMHC') " + "AND p.statC NOT IN ('NewPnRequest', 'Complete') "
            + "ORDER BY p.concernC DESC, p.partR")
    List<ReleaseStatusDto> fetchReleaseStatusDetails();

    @Modifying
    @Transactional
    @Query("UPDATE Part p " +
            "SET p.statC = 'HardLock', " +
            "p.stratCalibPartR = p.partR, " +
            "p.wersNtcR = :wersNtcR " +
            "WHERE p.partR = :partR")
    int updatePartStatusAndCalib(@Param("wersNtcR") String wersNtcR,
                                 @Param(Constants.PART_R) String partR);

    @Query("SELECT new com.ford.gpcse.dto.HardwareEmailPartDto(p.partR, p.engineerCdsidC, p.hardwarePartR, p.coreHardwarePartR, m.microTypX) " +
            "FROM Part p " +
            "JOIN p.microType m " +
            "WHERE p.reldF = 'Y' " +
            "AND p.partR IN :partNumbers " +
            "ORDER BY p.partR")
    List<HardwareEmailPartDto> fetchPartsForEmail(@Param("partNumbers") List<String> partNumbers);

    @Query("SELECT COUNT(p) FROM Part p WHERE p.partR = :partNumber")
    int countByPartNumber(@Param("partNumber") String partNumber);


    @Query("SELECT new com.ford.gpcse.dto.PrismDataInputDto(" +
            "p.partR, p.calibR, p.wersNtcR, p.stratRelC, p.stratCalibPartR, " +
            "p.chipD, p.hardwarePartR, p.catchWordC, p.reldY, " +
            "m.microTypX, r.relUsgC, " +
            "(SELECT pg.pgmN FROM ProgramDescription pg " +
            "JOIN ProgramPart pp ON pg.pgmK = pp.pgmK " +
            "WHERE pp.part.partR = p.partR ORDER BY pp.part.partR) AS vehicleLine, " +
            "(SELECT s.suplX FROM Supplier s WHERE s.suplC = p.supplier.suplC) AS supplier, " +
            "(SELECT pg.engN FROM ProgramDescription pg " +
            "JOIN ProgramPart pp ON pg.pgmK = pp.pgmK " +
            "WHERE pp.part.partR = p.partR ORDER BY pp.part.partR) AS engine, " +
            "p.releaseType.relTypC) " +
            "FROM Part p " +
            "LEFT JOIN p.microType m " +
            "LEFT JOIN p.releaseUsage r " +
            "WHERE p.partR = :partR AND p.archF = 'N'")
    PrismDataInputDto fetchPrismInputDataBasedOnPartNumber(@Param(Constants.PART_R) String partR);


    @Query("SELECT p.partR FROM Part p WHERE p.concernC = :wersConcern")
    List<String> fetchPartNumbersBasedOnConcern(@Param("wersConcern") String wersConcern);

    @Query("SELECT p.partR, " +
            "p.releaseType.relTypC, " +
            "p.backwardCompat.backwardCompatC, " +
            "p.hardwarePartR, " +
            "p.releaseUsage.relUsgC " +
            "FROM Part p " +
            "WHERE p.partR IN :partNumbers")
    List<Object[]> fetchParts(@Param("partNumbers") List<String> partNumbers);

    @Query("SELECT new com.ford.gpcse.dto.WersTextPartCalibDto("
            + "p.partR, p.replacedPartR, p.catchword.catchwordC, "
            + "p.partNumX, p.calibR, p.hardwarePartR, p.statC, "
            + "(SELECT sub.calibR FROM Part sub WHERE sub.partR = p.replacedPartR), "
            + "(SELECT sub.catchWordC FROM Part sub WHERE sub.partR = p.replacedPartR)) "
            + "FROM Part p "
            + "WHERE p.partR IN :partNumbers "
            + "ORDER BY p.replacedPartR, p.partNumX, p.partR")
    List<WersTextPartCalibDto> fetchPartsWithCalib(@Param("partNumbers") List<String> partNumbers);

    @Query("SELECT new com.ford.gpcse.dto.ModuleBaseInformationDto(p.partR, p.concernC, p.statC) " +
            "FROM Part p " +
            "WHERE p.archF = 'N' " +
            "AND upper(p.engineerCdsidC) = :engineerCdsid " +
            "AND p.reldF = 'N' " +
            "AND p.releaseType.relTypC NOT IN ('HRDCN', 'HWCUT', 'VCMHC') " +
            "AND p.statC IN ('PeadEdit', 'PeadComplete', 'FirmwareEdit', 'SoftLock') " +
            "ORDER BY p.concernC, p.partR")
    List<ModuleBaseInformationDto> fetchModuleBaseInformation(@Param("engineerCdsid") String engineerCdsid);

    @Query(value = "SELECT tblSoftRel.PCMR01_PART_R, PCMR01_PART_NUM_X, PCMR01_CATCHWORD_C, " +
            "PCMR01_CALIB_R, SUBSTRING(tblSoftRel.PCMR01_CALIB_R,0,9) ,SUBSTRING(tblSoftRel.PCMR01_CALIB_R,9,2) , PCMR01_STRAT_REL_C, " +
            "PCMR01_RELD_Y, PCMR01_CONCERN_C, PCMR01_ENGINEER_CDSID_C, PCMR01_HARDWARE_PART_R, PCMR01_CHIP_D, PCMR01_WERS_NTC_R, " +
            "PCMR01_STRAT_CALIB_PART_R, tblMainMicro.PCMR19_MICRO_TYP_X, PCMR01_HCR_R, PCMR24_REL_USG_X, PCMR01_SVC_MODULE_PART_R, " +
            "PCMR01_CONCERN_Y, PCMR39_CREATE_USER_C, PCMR17_SUPL_X, PCMR15_REL_TYP_X, PCMR26_BACKWARD_COMPAT_X, " +
            "PCMR01_REPLACED_PART_R, PCMR01_IPF_PART_R, PCMR01_BACKWARD_COMPAT_GRP_C, PCMR01_PWRTRN_CALIB_CDSID_C, PCMR01_STAT_C, PCMR01_CMT_X, PCMR01_STRAT_PART_R, " +
            "(Select tblSub.PCMR21_USER_CDSID_C FROM WPCMR21_SIGNOFF_PART tblSub WHERE tblSub.PCMR01_PART_R = tblSoftRel.PCMR01_PART_R and tblSub.PCMR20_SIGNOFF_TYP_C = 'PEERR'), " +
            "PCMS01_IVS_PGM_D, PCMR01_BLD_LVL_C, PCMR01_PRTY_C, PCMR01_PRTY_DTL_X, PCMR01_PROJ_CTL_ENG_CDSID_C, " +
            "(SELECT tblSub.PCMR21_USER_CDSID_C FROM WPCMR21_SIGNOFF_PART tblSub WHERE tblSub.PCMR01_PART_R = tblSoftRel.PCMR01_PART_R and tblSub.PCMR20_SIGNOFF_TYP_C = 'HWPER'), " +
            "(CASE WHEN (Select top 1 tSub.PCMR01_PART_R FROM WPCMR01_PART tSub WHERE tblSoftRel.PCMR01_PART_R = tSub.PCMR01_REPLACED_PART_R) IS NULL THEN 'N' ELSE 'Y' END), " +
            "(SELECT tblSub.PCMR21_USER_CDSID_C FROM WPCMR21_SIGNOFF_PART tblSub WHERE tblSub.PCMR01_PART_R = tblSoftRel.PCMR01_PART_R and tblSub.PCMR20_SIGNOFF_TYP_C = 'PEERR'), " +
            "PCMR01_OTA_F, PCMR01_DOMAIN_N, PCMR01_DOMAIN_INSTNC_N, PCMR01_VEH_CAN_TYP_C, PCMR01_CORE_HARDWARE_PART_R, " +
            "PCMR01_CORE_HARDWARE_CDSID_C, tblProg.PCMS01_MDL_YR_R, tblProg.PCMS01_PGM_N, tblProg.PCMS01_PLAT_N, tblProg.PCMS01_ENG_N, tblProg.PCMS01_TRANS_N, tblProg.PCMS01_ARCH_F, " +
            "PCMR01_CAL_REL_PLAN_Y, PCMR01_CAL_REL_ACT_Y " +
            "FROM WPCMR01_PART tblSoftRel " +
            "LEFT JOIN WPCMR19_MICRO_TYP tblMainMicro on tblSoftRel.PCMR19_MICRO_TYP_C = tblMainMicro.PCMR19_MICRO_TYP_C " +
            "LEFT JOIN WPCMR17_SUPL tblSup on tblSoftRel.PCMR17_SUPL_C = tblSup.PCMR17_SUPL_C " +
            "LEFT JOIN WPCMR15_REL_TYP tblRelType on tblSoftRel.PCMR15_REL_TYP_C = tblRelType.PCMR15_REL_TYP_C " +
            "LEFT JOIN WPCMR24_REL_USG tblRelUsage on tblSoftRel.PCMR24_REL_USG_C = tblRelUsage.PCMR24_REL_USG_C " +
            "LEFT JOIN WPCMR26_BACKWARD_COMPAT tblBackCompat on tblSoftRel.PCMR26_BACKWARD_COMPAT_C = tblBackCompat.PCMR26_BACKWARD_COMPAT_C " +
            "LEFT JOIN WPCMR04_PGM_PART tblProgPart on tblProgPart.PCMR01_PART_R = tblSoftRel.PCMR01_PART_R " +
            "LEFT JOIN WPCMS01_PGM_DESC tblProg on tblProg.PCMS01_PGM_K = tblProgPart.PCMS01_PGM_K " +
            "LEFT JOIN WPCMR39_LABEL_USG tblLabel on tblLabel.PCMR39_LABEL_USG_K = tblSoftRel.PCMR39_LABEL_USG_K " +
            "WHERE tblSoftRel.PCMR01_PART_R IN :partNumbers " +
            "ORDER BY PCMR01_WERS_NTC_R, PCMR01_CONCERN_C, PCMR01_PART_R, tblProg.PCMS01_MDL_YR_R, tblProg.PCMS01_PGM_N, tblProg.PCMS01_ENG_N, tblProg.PCMS01_TRANS_N",
            nativeQuery = true)
    List<Object[]> findAllPartsByIds(@Param("partNumbers") List<String> partNumbers);




}