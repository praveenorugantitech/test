package com.ford.gpcse.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR02_PART_FIRMWARE")
public class PartFirmware {

    @EmbeddedId
    private PartFirmwareId partFirmwareId;

    @ManyToOne
    @JoinColumn(name = "PCMR01_PART_R", referencedColumnName = "PCMR01_PART_R", insertable = false, updatable = false)
    private Part part;


    @ManyToOne
    @JoinColumn(name = "PCMR03_FIRMWARE_K", referencedColumnName = "PCMR03_FIRMWARE_K", insertable = false, updatable = false)
    private Firmware firmware;

    @Column(name = "PCMR02_FILE_N", length = 66)
    private String fileN;

    @Column(name = "PCMR02_APRVD_BY_CDSID_C", length = 8)
    private String aprvdByCdsidC;
    @Column(name = "PCMR02_APRVD_Y")
    private LocalDate aprvdY;

    @Column(name = "PCMR02_REQT_Y")
    private LocalDate reqtY;

    @Column(name = "PCMR02_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR02_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR02_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR02_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    @Column(name = "PCMR02_FILE_U", length = 2000)
    private String fileU;

    @Lob
    @Column(name = "PCMR02_FILE_L")
    private byte[] fileL;
}