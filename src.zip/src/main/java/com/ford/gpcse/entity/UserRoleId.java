package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Embeddable
public class UserRoleId {

    @Column(name = "PCM001_USER_CDSID_C", length = 8, nullable = false)
    private String userCdsidC;

    @Column(name = "PCM002_ROLE_K", nullable = false)
    private Long roleK;
}
