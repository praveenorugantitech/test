package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR20_SIGNOFF")
public class Signoff {

    @Id
    @Column(name = "PCMR20_SIGNOFF_TYP_C", length = 5)
    private String signoffTypC;

    @Column(name = "PCMR20_SIGNOFF_TYP_X")
    private String signoffTypX;

    @Column(name = "PCMR20_ARCH_F")
    private String archF;

    @Column(name = "PCMR20_SORT_ORD_R")
    private Long sortOrdR;

    @Column(name = "PCMR20_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR20_CREATE_S", nullable = false, updatable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR20_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR20_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;
}
